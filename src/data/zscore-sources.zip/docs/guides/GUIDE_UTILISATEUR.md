# Guide utilisateur — Z-score Niger 5.1.1

## Démarrer

Ouvrir l’application par HTTPS ou avec le serveur local. Choisir français, anglais ou arabe et le thème. Cliquer sur le logo Z pour ouvrir/rétracter le menu sur ordinateur. Le mode hors ligne est disponible après le chargement complet signalé en bas. Conserver la même adresse et le même profil de navigateur pour retrouver les dossiers.

L’application calcule localement, sans compte ni transmission des dossiers. Utiliser un identifiant ou pseudonyme. Le stockage dans le navigateur n’est pas chiffré et peut être effacé par le navigateur ou une personne ayant accès au profil. Faire des copies sur un support protégé.

## Calcul individuel

Saisir identifiant et pseudonyme facultatifs, âge, date de mesure, poids **en grammes**, longueur/taille **en cm**, sexe, position et œdèmes bilatéraux. Les œdèmes doivent être renseignés explicitement : aucune absence n’est présumée. Les dates connues sont préférables à l’âge estimé. Le mois moyen OMS compte 30,4375 jours. Le calcul sélectionne OMS 2006 avant 60 mois moyens, OMS 2007 de 60 à moins de 229 mois.

Cliquer **Calculer**. **Sauvegarder** conserve une version explicite ; la sauvegarde automatique protège aussi le travail commencé. L’état à droite du titre distingue prêt, en cours, enregistré et échec. Une mesure changée après calcul rend le résultat à recalculer. Les actions PDF, CSV et impression utilisent les valeurs enregistrées, avec leur référence et date de calcul.

### Tableau de bord après calcul

Après un calcul réussi, la saisie se replie et les résultats utilisent toute la largeur. Sur grand écran : synthèse et indicateurs à gauche, mesures calculées et visites du dossier à droite. **Modifier les mesures** rouvre les champs sans effacer les valeurs ; **Afficher les résultats** revient à la vue large. Une modification conserve l'ancien résultat avec un avertissement jusqu'au prochain calcul. **Sauvegarder** reste disponible dans la vue résultats.

Les groupes de courbes se déplient à la demande. Les trois courbes de croissance se répartissent sur trois colonnes lorsque la largeur suffit. Les quatre graphiques d’évolution des Z-scores tiennent sur une seule ligne lorsque l’espace le permet ; leur largeur s’adapte à la fenêtre et ils passent sur plusieurs lignes sur les écrans plus petits. Chaque graphique peut aussi être replié séparément. Les mesures techniques, références et visites restent consultables dans leurs sections dépliables. Une petite fenêtre ou l'ouverture de toutes les courbes peut nécessiter un défilement ; aucun résultat ou avertissement clinique n'est tronqué pour tenir artificiellement sur un écran.

### Lire les indicateurs

- **Poids pour âge (P/A)** : situe le poids selon âge et sexe ; ne distingue pas à lui seul petite taille et maigreur.
- **Taille pour âge (T/A)** : situe la croissance en longueur/taille selon âge et sexe.
- **Poids pour longueur/taille (P/T)** : situe le poids par rapport à la longueur/taille ; non applicable dans OMS 2007.
- **IMC pour âge** : IMC = poids en kg / taille en mètres au carré, comparé à la référence selon âge et sexe.

Z = 0 correspond à la médiane de référence. Une valeur négative n’est pas automatiquement une maladie. Le libellé concerne uniquement l’indicateur affiché. Les centiles P sont fournis entre −3 et +3 ; un tiret ne signifie pas zéro. Les domaines et suspensions propres à chaque indicateur sont explicités. Les valeurs hors table ne sont pas extrapolées.

### PB et évaluation clinique

Ouvrir la section repliable pour saisir le **PB en millimètres** et les observations du soignant. Toutes les nouvelles observations cliniques commencent « Non renseigné ». Ne pas utiliser « Non » pour une observation non faite. Le grade des œdèmes doit être cohérent avec leur présence.

La **synthèse du dépistage** est séparée des **indicateurs de croissance**. Elle expose le critère retenu et l’orientation proposée. Un PB sévère peut justifier une évaluation rapide même si les Z-scores ne montrent pas de déficit. Les informations manquantes restent visibles dans les détails. Aucun traitement ou admission n’est décidé automatiquement. Voir [règles et sources](../references/EVALUATION_NUTRITIONNELLE.md).

## Suivre un dossier

**Nouvelle visite** conserve l’identité et ouvre de nouvelles mesures. Garder un identifiant stable par enfant ; un nom seul ne suffit pas à éviter les homonymes. Les visites, dates, résultats enregistrés et courbes sont rapprochés par identifiant, avec signalement des conflits d’identité. Les copies d’une même visite ne créent pas artificiellement une nouvelle observation.

**Reprendre un travail** ouvre les sauvegardes : rechercher identifiant, nom, brouillon ou date, consulter un aperçu puis reprendre. Le travail courant est conservé avant remplacement de l’écran. **Nouveau travail** ouvre un espace vide après préservation du précédent.

## Traitement par lots

Ajouter les mesures à gauche, voir les fiches à droite. Le tableau présente huit lignes par page avec plage de résultats, numéros et flèches. Les exports et impressions portent sur tout le lot, pas uniquement la page visible.

Ouvrir **Importer ou coller un CSV** pour choisir le fichier ou coller les lignes. Télécharger le modèle. Colonnes possibles : name, caseId, ageMode, ageYears, ageMonths, ageDays, birthDate, measurementDate, weight, height, gender (M/F), position (L/H), oedema (n/y), muac et observations cliniques. Pour leurs valeurs techniques, consulter le code du modèle ou le [guide PB](../references/EVALUATION_NUTRITIONNELLE.md). Tout le fichier est validé avant ajout ; un fichier invalide n’ajoute aucune ligne. Limites CSV : 2 Mo et 500 lignes.

Sous le tableau, **Résumé du lot** décrit les fiches et leurs résultats utilisables, avec dénominateur propre à chaque indicateur. Une visite répétée reste une fiche ; ce n’est pas une estimation de prévalence ou un nombre de patients distincts. **Rapport agrégé / DHIS2** exporte des comptes sans noms ni identifiants et prépare, avec un profil validé, un fichier pour le destinataire. Aucun envoi automatique : voir [interopérabilité](../references/INTEROPERABILITE.md).

## Sauvegardes et transfert

- **Exporter la sauvegarde complète** : fichier `.zscore`, non chiffré, contenant versions, brouillons, mesures, résultats et préférences archivées.
- **Sauvegarde chiffrée** : protège le même contenu dans un fichier `.zscore.enc` avec une phrase secrète. La conserver séparément ; aucun mot de passe ne peut être récupéré.
- **Importer une sauvegarde** : sélection du fichier, phrase secrète si nécessaire, vérification complète, aperçu puis confirmation d’ajout. Les enregistrements existants restent conservés.

**Espace et copies de sauvegarde** indique versions, taille approximative et stockage/quota du navigateur. Ce n’est pas une sauvegarde supplémentaire. Actualiser relit les estimations. Le chiffrement protège le fichier exporté, pas le profil navigateur, les PDF, CSV ou copies de préparation d’import.

Pour un transfert A → B : exporter sur A, déplacer le fichier sur un support sûr, ouvrir la même version sur B et importer, vérifier l’aperçu puis confirmer. Vérifier les dossiers avant de modifier un appareil. Le [format](../references/FORMAT_SAUVEGARDE.md) décrit les contrôles et limites, dont 1 GiB de contenu pour le chiffrement.

## Aide et limites

Les icônes d’information ouvrent une aide proche du champ ; les listes restent ancrées à leur bouton. L’information générale et les mentions sont accessibles en bas. Les sorties FR/EN/AR conservent les unités et références. Les libellés OMS ne constituent ni une prescription ni une certification par l’OMS ou l’UNICEF. Le soignant confirme l’examen, l’orientation, le suivi et les règles nationales applicables.
