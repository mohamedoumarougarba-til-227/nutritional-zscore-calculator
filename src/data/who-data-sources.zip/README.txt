WHO growth reference data - editable source package

WHO2006: WHO Anthro b776d8a12b1c97369c748b561159fd2ec4f4db58 (GPL version 3).
WHO2007: WHO AnthroPlus 7cfcdb39026e9a55de55732bc3cf14c82261bcf7 (GPL version 3 or later).

The originals folders contain the unchanged, editable upstream LMS tables.
The converted folders contain the exact readable JSON data distributed with Z-score Niger and their manifests.
Changes by Tout Informatique Lazaret: tabular columns encoded as JSON, keys renamed for the local data interface; numeric reference values unchanged.
For WHO2007, the last duplicate upstream month is retained for interpolation.
Sex 1 corresponds to M; sex 2 to F. Each table entry records L, M and S.

The full upstream licences and provenance are included. Preserve their notices and the rights granted by those licences.
This package contains reference data and explanatory metadata only, no application code and no patient records.
The TIL copyright over its original application code does not restrict these data licences.
This note may be redistributed with the data package. No WHO endorsement is claimed.
